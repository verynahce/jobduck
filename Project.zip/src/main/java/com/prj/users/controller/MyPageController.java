package com.prj.users.controller;

import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.prj.main.vo.ApplicationVo;
import com.prj.users.mapper.UserMapper;
import com.prj.users.vo.UserVo;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping("/User/MyPage")
public class MyPageController {
	
	@Autowired
	private UserMapper userMapper;
	
	@RequestMapping("/Home/View")
	public ModelAndView homeview(HttpServletRequest request, HttpServletResponse responese) {		
		
		//변수 받기
		HttpSession session = request.getSession();
		UserVo login = (UserVo) session.getAttribute("login");	 
				
		//나이 계산		
		String UYearStr =login.getUser_birthdate().substring(0, 4);
		int UYear = Integer.parseInt(UYearStr);
		int CYear = LocalDate.now().getYear();
		int age = CYear - UYear;
		
		
		//수 세기
		int  User_idx =login.getUser_idx();	    
		int  CountR= userMapper.countR(User_idx);
		int  CountB= userMapper.countB(User_idx);
		int  CountA= userMapper.countA(User_idx);
		int  CountS= userMapper.countS(User_idx);
	    		
		
		ModelAndView mv = new ModelAndView();
		mv.addObject("userVo",login);		
		mv.addObject("CountR",CountR);	
		mv.addObject("CountB",CountB);	
		mv.addObject("CountA",CountA);	
		mv.addObject("CountS",CountS);	
		mv.addObject("UYear",UYear);	
		mv.addObject("age",age);	
		mv.setViewName("user/mypage/home/view");
		return mv;
	}
	
	@RequestMapping("/Home/updateForm")
	 public ModelAndView homeupdateForm(UserVo uservo) {	
		
		UserVo vo = userMapper.getUser(uservo);
		
		
		//나이 계산		
		String UYearStr =vo.getUser_birthdate().substring(0, 4);
		int UYear = Integer.parseInt(UYearStr);
		int CYear = LocalDate.now().getYear();
		int age = CYear - UYear;
		
		
        ModelAndView mv = new ModelAndView();		
		mv.setViewName("user/mypage/home/update");
		mv.addObject("userVo",vo);
		mv.addObject("UYear",UYear);	
		mv.addObject("age",age);
		return mv;
		
	}
	@RequestMapping("/Home/update")
	public ModelAndView homeupdate(UserVo uservo) {
	
		userMapper.updateUser(uservo);
	//	int user_idx= uservo.getUser_idx();
		
    ModelAndView mv = new ModelAndView();		
	 mv.setViewName("redirect:/User/MyPage/Home/View");
    return mv;
	}
	
	@RequestMapping("/ApplyList/List")
	public ModelAndView appplylist(UserVo uservo) {
	
   ApplicationVo vo =userMapper.getApplycation(uservo.getUser_id());
	//List <String> =	userMapper.getPost_idx()
	ModelAndView mv = new ModelAndView();
	mv.setViewName("user/mypage/applyList/list");
	return mv;
	
	}
}
