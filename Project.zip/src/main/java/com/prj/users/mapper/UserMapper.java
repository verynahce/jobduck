package com.prj.users.mapper;

import org.apache.ibatis.annotations.Mapper;

import com.prj.main.vo.ApplicationVo;
import com.prj.users.vo.UserVo;

@Mapper
public interface UserMapper {

	void insertUser(UserVo userVo);

	UserVo login(String userid, String passwd);

    int countR(int user_idx);

	int countB(int user_idx);

	int countA(int user_idx);

	int countS(int user_idx);

	UserVo getUser(UserVo uservo);

	void updateUser(UserVo uservo);

	ApplicationVo getApplycation(String user_id);




}
